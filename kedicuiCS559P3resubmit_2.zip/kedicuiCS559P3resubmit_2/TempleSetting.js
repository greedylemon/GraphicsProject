function setup() {"use strict"
  var canvas = document.getElementById('myCanvas');
  var context = canvas.getContext('2d');
  var m4 = twgl.m4;
  var slider1 = document.getElementById('slider1');
  var slider2 = document.getElementById('slider2');
  //var slider3 = document.getElementById('slider3');
  slider1.value = 0;
  slider2.value = 0;
  var x = 0;
  //slider3.value = 0;
  
                  
  function moveToTx(x,y,z,Tx) {
      var loc = [x,y,z];
      var locTx = m4.transformPoint(Tx,loc);
      context.moveTo(locTx[0]+250, -locTx[1]+250);
  }
  function lineToTx(x,y,z,Tx) {
      var loc = [x,y,z];
      var locTx = m4.transformPoint(Tx,loc);
      context.lineTo(locTx[0]+250,-locTx[1]+250);
  }
  function drawAxes(Tx) {
    context.beginPath();context.strokeStyle = "red"; moveToTx(0,0,0,Tx);lineToTx(250,0,0,Tx);context.stroke();
    context.beginPath();context.strokeStyle = "green";
    moveToTx(0,0,0,Tx);lineToTx(0,250,0,Tx);context.stroke();
    context.beginPath();context.strokeStyle = "blue";
    moveToTx(0,0,0,Tx);lineToTx(0,0,250,Tx);context.stroke();

   
  }
                
    function drawV(Tx) {
    context.strokeStyle = "red";
    moveToTx(50,0,50,Tx);lineToTx(50,0,200,Tx);context.stroke();
    lineToTx(100,100,200,Tx);lineToTx(100,100,50,Tx);lineToTx(50,0,50,Tx);context.stroke();
    lineToTx(0,100,50,Tx);lineToTx(0,100,200,Tx);lineToTx(50,0,200,Tx);context.stroke();
    moveToTx(50,40,200,Tx);lineToTx(80,100,200,Tx);lineToTx(100,100,200,Tx);context.stroke();
    moveToTx(50,40,200,Tx);lineToTx(20,100,200,Tx);lineToTx(0,100,200,Tx);context.stroke();
    moveToTx(50,40,50,Tx);lineToTx(80,100,50,Tx);lineToTx(100,100,50,Tx);context.stroke();
    moveToTx(50,40,50,Tx);lineToTx(20,100,50,Tx);lineToTx(0,100,50,Tx);context.stroke();
    moveToTx(20,100,200,Tx);lineToTx(20,100,50,Tx);context.stroke();
    moveToTx(80,100,200,Tx);lineToTx(80,100,50,Tx);context.stroke();
    moveToTx(50,40,200,Tx);lineToTx(50,40,50,Tx);context.stroke();
  }
    function drawL(Tx) {
    moveToTx(0,200,200,Tx);lineToTx(30,200,200,Tx);lineToTx(20,190,200,Tx);lineToTx(20,120,200,Tx);
    lineToTx(80,120,200,Tx);lineToTx(100,140,200,Tx);lineToTx(100,100,200,Tx);lineToTx(0,100,200,Tx);
    lineToTx(0,200,200,Tx);
    context.stroke();
    moveToTx(0,200,50,Tx);lineToTx(30,200,50,Tx);lineToTx(20,190,50,Tx);lineToTx(20,120,50,Tx);
    lineToTx(80,120,50,Tx);lineToTx(100,140,50,Tx);lineToTx(100,100,50,Tx);lineToTx(0,100,50,Tx);
    lineToTx(0,200,50,Tx);
    context.stroke();
    moveToTx(0,200,200,Tx);lineToTx(0,200,50,Tx);context.stroke();
    moveToTx(30,200,200,Tx);lineToTx(30,200,50,Tx);context.stroke();
    moveToTx(20,190,200,Tx);lineToTx(20,190,50,Tx);context.stroke();
    moveToTx(20,120,200,Tx);lineToTx(20,120,50,Tx);context.stroke();
    moveToTx(80,120,200,Tx);lineToTx(80,120,50,Tx);context.stroke();
    moveToTx(100,140,200,Tx);lineToTx(100,140,50,Tx);context.stroke();
    moveToTx(100,100,200,Tx);lineToTx(100,100,50,Tx);context.stroke();
    moveToTx(0,100,200,Tx);lineToTx(0,100,50,Tx); context.stroke();
    moveToTx(0,200,200,Tx);context.stroke();context.stroke();
  }
                  
function drawE(Tx){
    
     moveToTx(100,0,200,Tx);lineToTx(100,10,200,Tx);lineToTx(110,10,200,Tx);
     lineToTx(110,90,200,Tx);lineToTx(100,90,200,Tx);lineToTx(100,100,200,Tx);
     lineToTx(200,100,200,Tx);lineToTx(200,70,200,Tx);lineToTx(180,70,200,Tx);
     lineToTx(180,80,200,Tx);lineToTx(160,90,200,Tx);lineToTx(140,90,200,Tx);
     lineToTx(140,55,200,Tx);lineToTx(160,55,200,Tx);lineToTx(160,60,200,Tx);
     lineToTx(170,60,200,Tx);lineToTx(170,40,200,Tx);lineToTx(150,40,200,Tx);
     lineToTx(150,45,200,Tx);lineToTx(140,45,200,Tx);lineToTx(140,10,200,Tx);
     lineToTx(160,10,200,Tx);lineToTx(180,30,200,Tx);lineToTx(180,40,200,Tx);
     lineToTx(200,40,200,Tx);lineToTx(200,0,200,Tx);lineToTx(100,0,200,Tx);
     
     context.stroke();
     moveToTx(100,0,50,Tx);lineToTx(100,10,50,Tx);lineToTx(110,10,50,Tx);
     lineToTx(110,90,50,Tx);lineToTx(100,90,50,Tx);lineToTx(100,100,50,Tx);
     lineToTx(200,100,50,Tx);lineToTx(200,70,50,Tx);lineToTx(180,70,50,Tx);
     lineToTx(180,80,50,Tx);lineToTx(160,90,50,Tx);lineToTx(140,90,50,Tx);
     lineToTx(140,55,50,Tx);lineToTx(160,55,50,Tx);lineToTx(160,60,50,Tx);
     lineToTx(170,60,50,Tx);lineToTx(170,40,50,Tx);lineToTx(150,40,50,Tx);
     lineToTx(150,45,50,Tx);lineToTx(140,45,50,Tx);lineToTx(140,10,50,Tx);
     lineToTx(160,10,50,Tx);lineToTx(180,30,50,Tx);lineToTx(180,40,50,Tx);
     lineToTx(200,40,50,Tx);lineToTx(200,0,50,Tx);lineToTx(100,0,50,Tx);
     
     context.stroke();
     moveToTx(100,0,200,Tx);lineToTx(100,0,50,Tx);context.stroke();
     moveToTx(100,10,200,Tx);lineToTx(100,10,50,Tx);context.stroke();
     moveToTx(110,10,200,Tx);lineToTx(110,10,50,Tx);context.stroke();
     moveToTx(110,90,200,Tx);lineToTx(110,90,50,Tx);context.stroke();
     moveToTx(100,90,200,Tx); lineToTx(100,90,50,Tx);context.stroke();
     moveToTx(100,100,200,Tx); lineToTx(100,100,50,Tx);context.stroke();
     moveToTx(200,100,200,Tx);lineToTx(200,100,50,Tx);context.stroke();
     moveToTx(200,70,200,Tx);lineToTx(200,70,50,Tx);context.stroke();
     moveToTx(180,70,200,Tx);lineToTx(180,70,50,Tx);context.stroke();
     moveToTx(180,80,200,Tx);lineToTx(180,80,50,Tx);context.stroke();
     moveToTx(160,90,200,Tx);lineToTx(160,90,50,Tx);context.stroke();
     moveToTx(140,90,200,Tx); lineToTx(140,90,50,Tx);context.stroke();
     moveToTx(140,55,200,Tx);lineToTx(140,55,50,Tx);context.stroke();
     moveToTx(160,55,200,Tx);lineToTx(160,55,50,Tx);context.stroke();
     moveToTx(160,60,200,Tx);lineToTx(160,60,50,Tx);context.stroke();
     moveToTx(170,60,200,Tx);lineToTx(170,60,50,Tx);context.stroke();
     moveToTx(170,40,200,Tx);lineToTx(170,40,50,Tx);context.stroke();
     moveToTx(150,40,200,Tx);lineToTx(150,40,50,Tx);context.stroke();
     moveToTx(150,45,200,Tx);lineToTx(150,45,50,Tx);context.stroke();
     moveToTx(140,45,200,Tx);lineToTx(140,45,50,Tx);context.stroke();
     moveToTx(140,10,200,Tx);lineToTx(140,10,50,Tx);context.stroke();
     moveToTx(160,10,200,Tx);lineToTx(160,10,50,Tx);context.stroke();
     moveToTx(180,30,200,Tx);lineToTx(180,30,50,Tx);context.stroke();
     moveToTx(180,40,200,Tx);lineToTx(180,40,50,Tx);context.stroke();
     moveToTx(200,40,200,Tx);lineToTx(200,40,50,Tx);context.stroke();
     moveToTx(200,0,200,Tx);lineToTx(200,0,50,Tx);context.stroke();
     moveToTx(100,0,200,Tx);lineToTx(100,0,50,Tx);context.stroke();
     
   }                
                  
   function drawO(Tx){
    moveToTx(180,200,200,Tx);lineToTx(185,198,200,Tx);lineToTx(190,195,200,Tx);
    lineToTx(195,190,200,Tx);lineToTx(197,185,200,Tx);lineToTx(199,180,200,Tx);
    lineToTx(200,178,200,Tx);lineToTx(200,122,200,Tx);lineToTx(199,120,200,Tx);
    lineToTx(197,115,200,Tx);lineToTx(195,110,200,Tx);lineToTx(190,105,200,Tx);
    lineToTx(185,102,200,Tx);lineToTx(180,100,200,Tx);lineToTx(120,100,200,Tx);
    lineToTx(115,102,200,Tx);lineToTx(110,104,200,Tx);lineToTx(105,109,200,Tx);
    lineToTx(103,114,200,Tx);lineToTx(101,119,200,Tx);lineToTx(100,122,200,Tx);
    lineToTx(100,178,200,Tx);lineToTx(100,180,200,Tx);lineToTx(102,184,200,Tx);
    lineToTx(104,189,200,Tx);lineToTx(109,195,200,Tx);lineToTx(115,198,200,Tx);
    lineToTx(122,200,200,Tx);lineToTx(180,200,200,Tx);
    context.stroke();
    moveToTx(120,120,200,Tx);lineToTx(145,120,200,Tx);lineToTx(180,155,200,Tx);
    lineToTx(180,180,200,Tx);lineToTx(155,180,200,Tx);lineToTx(120,145,200,Tx);
    lineToTx(120,120,200,Tx);
    context.stroke();
    moveToTx(180,200,50,Tx);lineToTx(185,198,50,Tx);lineToTx(190,195,50,Tx);
    lineToTx(195,190,50,Tx);lineToTx(197,185,50,Tx);lineToTx(199,180,50,Tx);
    lineToTx(200,178,50,Tx);lineToTx(200,122,50,Tx);lineToTx(199,120,50,Tx);
    lineToTx(197,115,50,Tx);lineToTx(195,110,50,Tx);lineToTx(190,105,50,Tx);
    lineToTx(185,102,50,Tx);lineToTx(180,100,50,Tx);lineToTx(120,100,50,Tx);
    lineToTx(115,102,50,Tx);lineToTx(110,104,50,Tx);lineToTx(105,109,50,Tx);
    lineToTx(103,114,50,Tx);lineToTx(101,119,50,Tx);lineToTx(100,122,50,Tx);
    lineToTx(100,178,50,Tx);lineToTx(100,180,50,Tx);lineToTx(102,184,50,Tx);
    lineToTx(104,189,50,Tx);lineToTx(109,195,50,Tx);lineToTx(115,198,50,Tx);
    lineToTx(122,200,50,Tx);lineToTx(180,200,50,Tx);
    context.stroke();
    moveToTx(120,120,50,Tx);lineToTx(145,120,50,Tx);lineToTx(180,155,50,Tx);
    lineToTx(180,180,50,Tx);lineToTx(155,180,50,Tx);lineToTx(120,145,50,Tx);
    lineToTx(120,120,50,Tx);
    context.stroke();
    
    
    moveToTx(180,200,200,Tx);lineToTx(180,200,50,Tx);context.stroke();
    moveToTx(185,198,200,Tx);lineToTx(185,198,50,Tx);context.stroke();
    moveToTx(190,195,200,Tx);lineToTx(190,195,50,Tx);context.stroke();
    moveToTx(195,190,200,Tx);lineToTx(195,190,50,Tx);context.stroke();
    moveToTx(197,185,200,Tx);lineToTx(197,185,50,Tx);context.stroke();
    moveToTx(199,180,200,Tx);lineToTx(199,180,50,Tx);context.stroke();
    moveToTx(200,178,200,Tx);lineToTx(200,178,50,Tx);context.stroke();
    moveToTx(200,122,200,Tx);lineToTx(200,122,50,Tx);context.stroke();
    moveToTx(199,120,200,Tx);lineToTx(199,120,50,Tx);context.stroke();
    moveToTx(197,115,200,Tx);lineToTx(197,115,50,Tx);context.stroke();
    moveToTx(195,110,200,Tx);lineToTx(195,110,50,Tx);context.stroke();
    moveToTx(190,105,200,Tx);lineToTx(190,105,50,Tx);context.stroke();
    moveToTx(185,102,200,Tx);lineToTx(185,102,50,Tx);context.stroke();
    moveToTx(180,100,200,Tx);lineToTx(180,100,50,Tx);context.stroke();
    moveToTx(120,100,200,Tx);lineToTx(120,100,50,Tx);context.stroke();
    moveToTx(115,102,200,Tx);lineToTx(115,102,50,Tx);context.stroke();
    moveToTx(110,104,200,Tx);lineToTx(110,104,50,Tx);context.stroke();
    moveToTx(105,109,200,Tx);lineToTx(105,109,50,Tx);context.stroke();
    moveToTx(103,114,200,Tx);lineToTx(103,114,50,Tx);context.stroke();
    moveToTx(101,119,200,Tx);lineToTx(101,119,50,Tx);context.stroke();
    moveToTx(100,122,200,Tx);lineToTx(100,122,50,Tx);context.stroke();
    moveToTx(100,178,200,Tx);lineToTx(100,178,50,Tx);context.stroke();
    moveToTx(100,180,200,Tx);lineToTx(100,180,50,Tx);context.stroke();
    moveToTx(102,184,200,Tx);lineToTx(102,184,50,Tx);context.stroke();
    moveToTx(104,189,200,Tx);lineToTx(104,189,50,Tx);context.stroke();
    moveToTx(109,195,200,Tx);lineToTx(109,195,50,Tx);context.stroke();
    moveToTx(115,198,200,Tx);lineToTx(115,198,50,Tx);context.stroke();
    moveToTx(122,200,200,Tx);lineToTx(122,200,50,Tx);context.stroke();
    moveToTx(180,200,200,Tx);lineToTx(180,200,50,Tx);context.stroke();
    moveToTx(120,120,200,Tx);lineToTx(120,120,50,Tx);context.stroke();
    moveToTx(145,120,200,Tx);lineToTx(145,120,50,Tx);context.stroke();
    moveToTx(180,155,200,Tx);lineToTx(180,155,50,Tx);context.stroke();
    moveToTx(180,180,200,Tx);lineToTx(180,180,50,Tx);context.stroke();
    moveToTx(155,180,200,Tx);lineToTx(155,180,50,Tx);context.stroke();
    moveToTx(120,145,200,Tx);lineToTx(120,145,50,Tx);context.stroke();
    moveToTx(120,120,200,Tx);lineToTx(120,120,50,Tx);context.stroke();
       
   }
  function drawU(Tx) {
       moveToTx(300,100,200,Tx);lineToTx(330,100,200,Tx);lineToTx(330,30,200,Tx);
    lineToTx(370,30,200,Tx);lineToTx(370,30,200,Tx);lineToTx(370,100,200,Tx);
    lineToTx(400,100,200,Tx);lineToTx(400,0,200,Tx);lineToTx(300,0,200,Tx);
    lineToTx(300,100,200,Tx);
    
    
    context.stroke();
    moveToTx(300,100,50,Tx);lineToTx(330,100,50,Tx);lineToTx(330,30,50,Tx);
    lineToTx(370,30,50,Tx);lineToTx(370,30,50,Tx);lineToTx(370,100,50,Tx);
    lineToTx(400,100,50,Tx);lineToTx(400,0,50,Tx);lineToTx(300,0,50,Tx);
    lineToTx(300,100,50,Tx);
    
   
    
    
    context.stroke();
    moveToTx(300,100,200,Tx); lineToTx(300,100,50,Tx); context.stroke();
    moveToTx(330,100,200,Tx);lineToTx(330,100,50,Tx); context.stroke();
    moveToTx(330,30,200,Tx);lineToTx(330,30,50,Tx); context.stroke();
    moveToTx(370,30,200,Tx);lineToTx(370,30,50,Tx); context.stroke();
    moveToTx(370,30,200,Tx);lineToTx(370,30,50,Tx); context.stroke();
    moveToTx(370,100,200,Tx);lineToTx(370,100,50,Tx); context.stroke();
    moveToTx(400,100,200,Tx);lineToTx(400,100,50,Tx); context.stroke();
    moveToTx(400,0,200,Tx);lineToTx(400,0,50,Tx); context.stroke();
    moveToTx(300,0,200,Tx);lineToTx(300,0,300,50,Tx); context.stroke();
    moveToTx(300,100,200,Tx);lineToTx(300,100,50,Tx); context.stroke();
    moveToTx(300,0,200,Tx);lineToTx(300,0,50,Tx);context.stroke();
  }             
                  
  function draw() {
      canvas.width = canvas.width;
      var angle1 = slider1.value*0.01*Math.PI;
      var angle2 = slider2.value*0.01*Math.PI;
      var axis = [1,1,1];
      var Tmodel = m4.axisRotation(axis,angle2);
      var eye = [500*Math.cos(angle1), 300, 500*Math.sin(angle1)];
      var target = [0,0,0];
      var up = [0,1,0];
      var Tcamera = m4.inverse(m4.lookAt(eye,target,up));
      var Tmodelview = m4.multiply(Tmodel,Tcamera);
      drawV(Tmodelview);
      //drawL(Tmodel)
      drawL(Tmodelview);
      drawE(Tmodelview);
      drawO(Tmodelview);
      context.save();
      x += slider3.value * 0.001;
      var flag = [50,50,125];
      var Rotation = m4.multiply(m4.rotationY(x),m4.translation(flag));
      var whole = m4.multiply(Rotation,Tmodelview);
      drawU(whole);
      context.restore();
      drawAxes(Tcamera);
  }
      //slider1.addEventListener("input",draw);
      //slider2.addEventListener("input",draw);
      //slider3.addEventListener("input",draw);
      //draw();
      window.setInterval(draw,16);
}
window.onload = setup;